using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    [Range(0.01f, 20.0f)][SerializeField] private float moveSpeed = 0.1f;
    [SerializeField] private float jumpForce = 6.0f;
    [SerializeField] private float rayOffset = 0.5f;
    [SerializeField] private float fallGravity = 1.5f;
    [SerializeField] private AudioClip bSound;
    [SerializeField] private AudioClip jumpSound;
    [SerializeField] private AudioClip hurtSound;
    [SerializeField] private AudioClip keySound;
    [SerializeField] private AudioClip heartSound;
    [SerializeField] private AudioClip crushingSound;
    [SerializeField] private AudioClip levelCompleted;
    [SerializeField] private AudioClip ladderClimbing;
    [SerializeField] private AudioClip dashSound;
    private AudioSource source;
    private Rigidbody2D rigidBody;
    private TrailRenderer trail;
    public LayerMask groundLayer;
    const float rayLength = 0.5f;
    private Animator animator;
    private bool isWalking = false;
    private bool isFacingRight = true;
    private bool isLadder = false;
    private bool isClimbing = false;
    private bool isJumping = false;
    private float vertical;
    private Vector2 startPosition;
    private int keysFound = 0;
    private const int keysNumber = 3;
    private int lives = 3;
    bool grounded = true;
    private float jumpCooldown = 0.35f;
    private float jumpStartTime = 0.0f;
    Vector2 leftRayOrigin;
    Vector2 rightRayOrigin;
    bool firstJump = false;
    public ParticleSystem dust;

    [SerializeField] private Transform groundCheck;  // Punkt do sprawdzania pod�o�a (np. pod stopami gracza)
    [SerializeField] private float groundCheckRadius = 0.2f;

    [Header("Dashing")]
    [SerializeField] private float dashingVelocity;
    [SerializeField] private float dashingTime;
    private bool isDashing = false;
    private Vector2 dashDirection;
    private bool canDash = true;


    bool IsGrounded()
    {
        // Pozycje startowe dla dw�ch promieni
       /* leftRayOrigin = new Vector2(this.transform.position.x - rayOffset, this.transform.position.y-0.6f);
        rightRayOrigin = new Vector2(this.transform.position.x + rayOffset, this.transform.position.y-0.6f);

        // Tworzenie dw�ch raycast�w
        bool leftRayHit = Physics2D.Raycast(leftRayOrigin, Vector2.down, rayLength, groundLayer.value);
        bool rightRayHit = Physics2D.Raycast(rightRayOrigin, Vector2.down, rayLength, groundLayer.value);

        return leftRayHit || rightRayHit;*/

        return Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
    }

    void Jump()
    {
        if (IsGrounded())
        {
            CreateDust();
            source.PlayOneShot(jumpSound, AudioListener.volume);
            isJumping = true;
            firstJump = true;
            jumpStartTime = Time.time;
            animator.SetBool("isJumping", isJumping);
            rigidBody.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            Debug.Log("jumping");
        }else if (firstJump)
        {
            CreateDust();
            source.PlayOneShot(jumpSound, AudioListener.volume);
            isJumping = true;
            firstJump = false;
            jumpStartTime = Time.time;
            animator.SetBool("isJumping", isJumping);
            rigidBody.velocity = new Vector2(rigidBody.velocity.x, 0); // resetowanie pr�dko�ci w osi y
            rigidBody.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
            Debug.Log("double jumping");
        }
    }

    void Dash()
    {
        if (!isDashing && canDash)
        {
            animator.SetBool("isDashing", true);
            source.PlayOneShot(dashSound, AudioListener.volume);
            trail.emitting = true;
            canDash = false;
            isDashing = true;
            dashDirection = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            if(dashDirection == Vector2.zero)
            {
                dashDirection = new Vector2(transform.localScale.x, 0);
            }
            rigidBody.gravityScale = 0;
            rigidBody.velocity = dashDirection.normalized * dashingVelocity;
            //rigidBody.velocity = new Vector2(rigidBody.velocity.x, 0);
            StartCoroutine(StopDashing());
        }
    }

    private IEnumerator StopDashing()
    {
        yield return new WaitForSeconds(dashingTime);
        isDashing = false;
        rigidBody.gravityScale = 1;
        rigidBody.velocity = new Vector2(0, 0);
        trail.emitting = false;
        animator.SetBool("isDashing", false);
    }


    void Awake()
    {
        startPosition = this.transform.position;
        rigidBody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        source = GetComponent<AudioSource>();
        trail = GetComponent<TrailRenderer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        isWalking = false;
        if (GameManager.instance.currentGamestate == GameState.GAME)
        {
            if ((Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D)) && !isDashing) //prawo
            {
                transform.Translate(moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isWalking = true;
                if (!isFacingRight)
                {
                    Flip();
                }
            }

            if ((Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A)) && !isDashing) //lewo
            {
                transform.Translate(-1 * moveSpeed * Time.deltaTime, 0.0f, 0.0f, Space.World);
                isWalking = true;
                if (isFacingRight)
                {
                    Flip();
                }
            }

            if (Input.GetKeyDown(KeyCode.Space))
            {
                Jump();
            }

            if (Input.GetKeyUp(KeyCode.Space))
            {
                rigidBody.velocity = new Vector2(rigidBody.velocity.x, rigidBody.velocity.y / 2);
                isJumping = false;
                animator.SetBool("isJumping", false);
            }

            if (Input.GetMouseButtonDown(0))
            {
                Dash();
            }
        }

        //Debug.DrawRay(transform.position, rayLength * Vector3.down, Color.white, 1, false);

        Debug.DrawRay(leftRayOrigin, Vector2.down * rayLength, Color.red);
        Debug.DrawRay(rightRayOrigin, Vector2.down * rayLength, Color.red);

        grounded = IsGrounded();

        if (grounded)
        {
            canDash = true;
        }

        animator.SetBool("isGrounded", grounded);

        if (isJumping && (Time.time > jumpStartTime + jumpCooldown))
        {
            isJumping = false;
            animator.SetBool("isJumping", false);
            Debug.Log("Landed");
        }

        animator.SetBool("isWalking", isWalking);

        vertical = Input.GetAxis("Vertical");

        if(isLadder && vertical > 0 && !isClimbing)
        {
            isClimbing = true;
            source.clip = ladderClimbing;
            source.loop = true;
            source.pitch = 1.5f;
            source.Play();
        }

        animator.SetBool("isClimbing", isClimbing);

    }

    private void FixedUpdate()
    {
        if (isClimbing)
        {
            rigidBody.gravityScale = 0;
            rigidBody.velocity = new Vector2(rigidBody.velocity.x, vertical * moveSpeed);
        }else if (isDashing)
        {
            rigidBody.gravityScale = 0;
        }
        else
        {
            rigidBody.gravityScale = 3;
        }

        if(grounded==false && isJumping == false)
        {
            rigidBody.gravityScale += fallGravity;
        }
        else
        {
            rigidBody.gravityScale = 3;
        }
        
    }

    void OnTriggerEnter2D(Collider2D cal)
    {
        if (cal.CompareTag("FallLevel"))
        {
            GameManager.instance.RemoveLife();
            transform.position = startPosition;
            lives--;
            if(lives == 0)
            {
                this.gameObject.SetActive(false); 
            }
        }

        if (cal.CompareTag("Bonus"))
        {
            GameManager.instance.AddPoints(10);
            source.PlayOneShot(bSound, AudioListener.volume);
        }

        if (cal.CompareTag("Ladder"))
        {
            isLadder = true;
        }

        if(cal.CompareTag("Enemy"))
        {
            if (this.transform.position.y > cal.gameObject.transform.position.y + 1.5f) // player over the enemy
            {
                isJumping = true;
                jumpStartTime = Time.time;
                animator.SetBool("isJumping", isJumping);
                rigidBody.velocity = new Vector2(rigidBody.velocity.x, 0); // resetowanie pr�dko�ci w osi y
                rigidBody.AddForce(Vector2.up * jumpForce * 0.5f, ForceMode2D.Impulse);
                firstJump = true;
                canDash = true;
                source.PlayOneShot(crushingSound, AudioListener.volume);
            }
            else // player below te enemy
            {
                source.PlayOneShot(hurtSound, AudioListener.volume);
                GameManager.instance.RemoveLife();
                this.transform.position = startPosition;
                lives--;
                if (lives == 0)
                {
                    this.gameObject.SetActive(false);
                }
            }
        }

        if (cal.CompareTag("Key"))
        {
            GameManager.instance.AddKey();
            source.PlayOneShot(keySound, AudioListener.volume);
            keysFound++;
        }

        if (cal.CompareTag("Heart"))
        {
            GameManager.instance.AddLife();
            Debug.Log("Heart found");
            source.PlayOneShot(heartSound, AudioListener.volume);
            if(lives<3)
                lives++;
        }

        if (cal.CompareTag("Finish"))
        {
            if (keysFound == 3)
            {
                GameManager.instance.AddPoints(30 * lives);
                source.PlayOneShot(levelCompleted, AudioListener.volume);
                GameManager.instance.LevelCompleted();
            }
            else
            {
                string endlog = "Brakuje ci ";
                endlog += (char)(keysNumber - keysFound + 48);
                endlog += " kluczy";
                Debug.Log(endlog);
            }
        }

        if (cal.CompareTag("movingPlatform"))
        {
            this.transform.SetParent(cal.transform);
        }

        if (cal.CompareTag("rotatingPlatform"))
        {
            this.transform.SetParent(cal.transform);
        }

    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag("Ladder"))
        {
            isLadder = false;
            if (isClimbing)
            {
                isClimbing = false;
                source.loop = false;
                source.Stop();
                source.pitch = 1.0f;
            }
        }

        if (col.CompareTag("movingPlatform"))
        {
            this.transform.SetParent(null);
        }

        if (col.CompareTag("movingPlatform"))
        {
            this.transform.SetParent(null);
        }
    }

    private void Flip()
    {
        isFacingRight = !isFacingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    private void CreateDust()
    {
        dust.Play();
    }

}
